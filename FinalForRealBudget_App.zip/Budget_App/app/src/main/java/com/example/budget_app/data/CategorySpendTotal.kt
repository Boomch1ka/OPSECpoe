package com.example.budget_app.data



data class CategorySpendTotal(
    val categoryName: String,
    val totalSpent: Double
)


